#LATAM Entity Type

##Descripción
Representa los tipo de entidades que participan en los distintos documentos.

|Nro|valor| Caption Eng | Caption Esp|
|---|-----|:-------------:|:------------:|
|0|Customer|'Customer'|Cliente"|
|1|Vendor|'Vendor'|Proveedor"|
|2|Bank|'Bank'|Banco"|
|3|Ledger|'Ledger'|Contabilidad"|
|4|Inventory|'Inventory'|Inventario"|
