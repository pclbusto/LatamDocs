# LATAM Setup
![Ventana Punto de Venta](../../Imagenes/LATAM-SalesPoint-MainPage.PNG)
## Descripción
Maestro de entidad punto de venta.

## Sección General
### Campos

>#### No.
>>**Descripción**: Identificador único para el punto de venta.
	
>>**Tipo**:text

>#### Descripción
>>**Descripción**:
	
>>**Tipo**:text

>#### Valida autorización
>>**Descripción**:
	
>>**Tipo**:Entero

>#### Prefijo Punto de Venta
>>**Descripción**:
	
>>**Tipo**:Entero

>#### Pre impreso
>>**Descripción**:
	
>>**Tipo**:Entero

>#### Auto Impreso
>>**Descripción**:
	
>>**Tipo**:Entero

>#### Impresora Fiscal
>>**Descripción**:
	
>>**Tipo**:Entero

>#### Reporte
>>**Descripción**:
	
>>**Tipo**:Entero

## Sección Depositos de punto de venta
### Campos
>#### Código Depósito
>>**Descripción**:
	
>>**Tipo**:Entero
>#### Descripción
>>**Descripción**: 
	
	
>>**Tipo**:Entero