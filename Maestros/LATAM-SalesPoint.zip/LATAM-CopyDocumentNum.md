#LATAM Copiar número de comprobante

##Descripción
Indica como va a ser el reemplazo de los numeradores de los distintos documentos.

|Nro|valor| Caption Eng | Caption Esp|
|---|-----|:-------------:|:------------:|
|0|None|'None'|Ninguno|
|1|VoucherNumber|'Voucher No.'|N° de comprobante|
|2|Invoice|'Invoice'|Factura|
|3|InvoiceAndVoucherNumber|'Invoice and Voucher No.'|Factura y N° de comprobante|
